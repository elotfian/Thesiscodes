 
function Z=MyCost(x,samplev,param)
  Z(2)=size(x,1);

a=param.a;
c0=param.c0;
c1=param.c1;


%% Relation (4.3)
F=squareform(pdist(x));
ss=F(:)';
[~,n]=size(ss);
varss=zeros(1,n);
for i=1:n
varss(i)=cv(a,ss(i),c0,c1);
end
Cmat=vec2mat(varss,sqrt(n)); %matrix C without one's
A=[Cmat ones(sqrt(n),1); [ones(1,sqrt(n)),0]]; %matrix C and one's
invA=pinv(A);
invCm=pinv(Cmat);
% d, lambda and sigma_ok w.r.t s_0 and equation (4.4)
for i=1:size(samplev,1)
d(i,:)=pdist2(samplev(i,:),x);
  [~,nd]=size(d(i,:));
  varss0=zeros(1,nd);
   for j=1:nd
   varss0(i,j)=cv(a,d(i,j),c0,c1);
   end

Lambda(i,:)=(invA*[varss0(i,:),1]')';
sigmaok(i)=c1-(Lambda(i,:)*[varss0(i,:),1]');
end

%% covariance between the varigram parameters equation (4.7)

rhoCc1=zeros(1,n); 
rhoCa=zeros(1,n); 
for i=1:n
[rhoCc1(i),rhoCa(i)]=parti(a,ss(i),c1);
end
RhoCc1=vec2mat(rhoCc1,sqrt(n));%\partial C / \partal c1
RhoCa=vec2mat(rhoCa,sqrt(n));%\partial C / \partal a
%covariance 4.7
covcc1ca=1/(0.5*trace((invCm*RhoCc1)*(invCm*RhoCa)));

DAc1=[RhoCc1 zeros(sqrt(n),1); [zeros(1,sqrt(n)),0]];%\partial A / \partial c1
DAa=[RhoCa zeros(sqrt(n),1); [zeros(1,sqrt(n)),0]]; %\partial A / \partial a

%\partial d
for i=1:size(samplev,1)
  [~,nd]=size(d(i,:));
   dc1varss0=zeros(1,nd);
   davarss0=zeros(1,nd);
   for j=1:nd
   [dc1varss0(i,j),davarss0(i,j)]=parti(a,d(i,j),c1);
   end
  
   Dc1varss0(i,:)=[dc1varss0(i,:),0];%\partial d / \partial c1
   Davarss0(i,:)=[davarss0(i,:),0]; %\partial d / \partial a
   DLamc1(i,:)=(invA*(Dc1varss0(i,:)-(DAc1*Lambda(i,:)')')')';
   DLama(i,:)=(invA*(Davarss0(i,:)-(DAa*Lambda(i,:)')')')';
end

Cmat2=[Cmat zeros(sqrt(n),1); [zeros(1,sqrt(n)),0]];
for i=1:size(samplev,1)
  ET(i)=covcc1ca*(DLamc1(i,:)*Cmat2*DLama(i,:)');
  sigma2p(i)=sigmaok(i)+ET(i);
end

Sigma2p=mean(sigma2p);


Z(1)=Sigma2p;





  end
 


