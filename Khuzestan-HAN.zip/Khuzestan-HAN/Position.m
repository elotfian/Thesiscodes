function pos=Position(lbm,lbp,nvar,ndiscp)

while true

pos=datasample(ndiscp,nvar,'Replace',false);
[Amoun,Aplain]=mounplain(pos);

 if min(pdist(Amoun))>lbm && min(pdist(Aplain))>lbp
     break;
 end
end


