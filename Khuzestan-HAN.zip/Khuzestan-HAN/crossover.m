function  crosspop=crossover(crosspop,pop,ncross,samplev,param,lbm,lbp,aproxpos)

npop=length(pop);


for n=1:2:ncross
    
%     id3=1;
%     while(id3==1)
    jj=0;
    id=1;
    while (id==1)
    

    i1=randi([1 npop]);
    i2=randi([1 npop]);
    
    
    p1=pop(i1).pos;
    p2=pop(i2).pos;
    
    
    
    
    if (size(p1,1)<=size(p2,1))
        nvar=size(p1,1);
        r=rand(1,nvar);
        
    o1=([r.*p1(:,1)';r.*p1(:,2)']+[(1-r).*p2(1:nvar,1)';(1-r).*p2(1:nvar,2)'])';
    o2=([r.*p2(1:nvar,1)';r.*p2(1:nvar,2)']+[(1-r).*p1(:,1)';(1-r).*p1(:,2)'])';
    else
        nvar=size(p2,1);
        r=rand(1,nvar);
        
    o1=([r.*p1(1:nvar,1)';r.*p1(1:nvar,2)']+[(1-r).*p2(:,1)';(1-r).*p2(:,2)'])';
    o2=([r.*p2(:,1)';r.*p2(:,2)']+[(1-r).*p1(1:nvar,1)';(1-r).*p1(1:nvar,2)'])';
    end
    
   
    for ji=1:nvar
       c=bsxfun(@minus,o1(ji,:),aproxpos);
       [out,idx]=min(hypot(c(:,1),c(:,2)));
        o1(ji,:)=aproxpos(idx,:);
        c2=bsxfun(@minus,o2(ji,:),aproxpos);
       [out2,idx2]=min(hypot(c2(:,1),c2(:,2)));
        o2(ji,:)=aproxpos(idx2,:);
     end

     [Amouno1,Aplaino1]=mounplain(o1);
     [Amouno2,Aplaino2]=mounplain(o2);
     Ftem1mouno1=min(pdist(Amouno1));
     Ftem1plaino1=min(pdist(Aplaino1));
     Ftem1mouno2=min(pdist(Amouno2));
     Ftem1plaino2=min(pdist(Aplaino2));

   
     if (Ftem1mouno1>lbm && Ftem1plaino1>lbp) && (Ftem1mouno2>lbm && Ftem1plaino2>lbp)
         id=0;
crosspop(n).pos=o1;
crosspop(n).cost=MyCost(o1,samplev,param)';

crosspop(n+1).pos=o2;
crosspop(n+1).cost=MyCost(o2,samplev,param)';
     
     else
          jj=jj+1;
          if jj==3
             if (Ftem1mouno1>lbm && Ftem1plaino1>lbp)
              crosspop(n).pos=o1;
              crosspop(n).cost=MyCost(o1,samplev,param)'; 
              crosspop(n+1).pos=o2;
              crosspop(n+1).cost=[10^6;10^6];
             elseif (Ftem1mouno2>lbm && Ftem1plaino2>lbp)
              crosspop(n).pos=o1;
              crosspop(n).cost=[10^6;10^6];
              crosspop(n+1).pos=o2;
              crosspop(n+1).cost=MyCost(o2,samplev,param)';
             else
              crosspop(n).pos=o1;
              crosspop(n).cost=[10^6;10^6];
              crosspop(n+1).pos=o2;
              crosspop(n+1).cost=[10^6;10^6];  
             end
         id=0;
         end
    end
    end


end





