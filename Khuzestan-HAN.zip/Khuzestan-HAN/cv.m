function  cvg=cv(a,h,c0,c1)

if h>a
    gh=c0+c1;
else
    gh=c0+c1*((1.5*h/a)-(0.5*(h/a)^3));
end

if h==0 
   cvg=c1;
else
cvg=c0+c1-gh;
end
end

