function  mutpop=mutation(mutpop,pop,nmut,samplev,param,lbm,lbp,aproxpos,minnvar,maxnvar)


npop=length(pop);


for n=1:nmut
    

   jj=0;    
   id=1;
   while (id==1)

   ii=randi([1 npop]);
   p=pop(ii).pos;
   
   j=randi([1 size(p,1)]);
 
   if rand<0.5
     if size(p,1)<minnvar
        mutpop(n).pos=pop(ii).pos;
        mutpop(n).cost=pop(ii).cost;
        id=0;
     else 
      p(j,:)=[];  
      mutpop(n).pos=p;
      mutpop(n).cost=MyCost(p,samplev,param)';
      id=0;
     end
   else
    if size(p,1)+1<=maxnvar 
    ptem=p(j,:)+rand*0.1*(p(j,:));     
    c=bsxfun(@minus,ptem,aproxpos);
    [out,idx]=min(hypot(c(:,1),c(:,2)));
    ptem=aproxpos(idx,:);
    p=[p
        ptem];
    end
   
   [Amoun,Aplain]=mounplain(p);
    
    
     if min(pdist(Amoun))>lbm && min(pdist(Aplain))>lbp
         id=0;
         mutpop(n).pos=p;
         mutpop(n).cost=MyCost(p,samplev,param)';
                        
     else
         jj=jj+1;
         if jj==3
         mutpop(n).pos=p;
         mutpop(n).cost=[10^6;10^6];
         id=0;
         end
     end
   end 
   end
   
  
   
     
end






