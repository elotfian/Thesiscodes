function  [rhoCc1,rhoCa]=parti(a,h,c1)

%\partial C / \partal c1
if h==0
    rhoCc1=1;
elseif h>a
      rhoCc1=0;
else
    rhoCc1=1-(1.5*h/a)+(0.5*((h/a)^3));

end


%\partial C / \partal a
if h==0 || h>a
    rhoCa=0;
else
    rhoCa=c1*1.5*((h/(a^2))-((h^3)/(a^4)));
end
end


