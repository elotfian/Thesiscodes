clear

xmax=100;
ymax=100;
xmin=0;
ymin=0;
lbc2=1;
nvar=50;
function pos=Position(xmin,ymin,xmax,ymax,lbc2,nvar)


x=xmin+(xmax-xmin)*rand(1,1);
y=ymin+(ymax-ymin)*rand(1,1);
pos(1,:)=[x,y];
i=1;

 while i<nvar
 x=xmax*rand(1,1);
 y=ymax*rand(1,1);
 a = bsxfun(@minus,[x y],pos);
 out = cellfun(@norm,num2cell(a,2));
 if sum(out>lbc2)>=i
 i=i+1;
 pos(i,:)=[x,y];
 end
 end
 
 
pop.pos=Position(xmin,ymin,xmax,ymax,lbc2,nvar)
plot(pop.pos)